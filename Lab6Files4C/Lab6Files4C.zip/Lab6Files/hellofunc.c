#include <stdio.h>

void myPrintHelloMake(void) {

  printf("Hello makefiles!\n");

  return;
}