#include <stdio.h>
#include "hellofunc.h"
int main() {
  // call a function in another file
  myPrintHelloMake();
  return(0);
}